import React from 'react'
const LoadMore = props => <a className="loadMore" onClick = {props.loadMore}><span> load more </span></a>
export default LoadMore
